<?php $__env->startSection('container'); ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <style>
        .btn-custom{
            background-color: #a748aa;
            color: white;
        }
        .form-group{
            padding-top: 3%;
        }
        .container{
            width: 70%;
            margin-top: 5%;
        }
        .text-custom{
            color: #a748aa;
        }
        .container-custom{
            width: 50%;
            margin-top: 5%;
        }

    </style>

    <title>JHFurniture Checkout</title>
  </head>
  <body>
    <div class="container">

        <div class="d-flex justify-content-center text-custom mb-3">
            <h2>
                Checkout
            </h2>
        </div>

        <?php $total = 0 ?>
        <?php $totals = 0 ?>

    <?php if(session('cart')): ?>
      <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $total += $item['price'] * $item['quantity'] ?>
        <div class="row">
            <div class="col"><img src="<?php echo e(url('storage/'.$item['image'])); ?>" style="max-width: 100px;"></div>
            <div class="col fw-bold"><?php echo e($item['name']); ?></div>
            <div class="col fw-bold">Rp.<?php echo e(number_format($item['price'], 0, '.', '.')); ?></div>
            <div class="col fw-bold"><?php echo e($item['quantity']); ?> item(s)</div>
            <div class="col fw-bold">Rp.<?php echo e(number_format($total, 0, '.', '.')); ?></div>
          </div>

          <?php $totals+= $total ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <div class="d-flex mt-3">
      <div class="col fw-bold text-center">Total : Rp.<?php echo e(number_format($totals, 0, '.', '.')); ?></div>
      </div>
      <form action="/transaction/finish" method="POST">
            <div class="d-flex justify-content-center">
                <div class="form-group">
                    <label for="payment" class=" col-form-label">Payment Method : </label>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input <?php $__errorArgs = ['payment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        type="radio" name="payment" id="Credit" value="Credit" required>
                        <label class="form-check-label" for="Credit">Credit</label>
                    </div>
                    <div class="form-check form-check-inline">
                      <input class="form-check-input <?php $__errorArgs = ['payment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                      type="radio" name="payment" id="Debit" value="Debit" required>
                      <label class="form-check-label" for="Credit">Debit</label>
                    </div>
                </div>
            </div>
            <div class="d-flex justify-content-center">
            <div class="form-group row">
                <label for="card" class="col col-form-label">Card Number</label>
                <div class="col-7">
                    <input type= "text" name = "card" class="form-control <?php $__errorArgs = ['card'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="card" placeholder="Enter your card number" autofocus required value=" <?php echo e(old('card')); ?> ">
                    <?php $__errorArgs = ['card'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger">
                        <?php echo e($message); ?>

                    </div>
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>
             <div class="d-flex justify-content-center mt-3">
                <button type="submit" class="btn btn-custom rounded-pill col-5 mt-3">Checkout</button>
            </div>
      </form>
      <?php else: ?>
      <br><br>
      <div class="d-flex justify-content-center text-dark fw-bold">
        <h2>
            No Item has been added to cart.
        </h2>
    </div>



    <?php endif; ?>

    <br><br>

    </div>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.container', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\JHFurniture\resources\views//transaction/checkout.blade.php ENDPATH**/ ?>