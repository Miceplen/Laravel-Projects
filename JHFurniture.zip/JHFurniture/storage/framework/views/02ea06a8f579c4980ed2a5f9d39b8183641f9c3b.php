<?php $__env->startSection('container'); ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <style>
        .btn-custom{
            background-color: white;
            color: #a748aa;
        }
        .form-group{
            padding-top: 3%;
        }
        .container{
            width: 85%;
            margin-top: 3%;
        }
        .text-custom{
            color: #a748aa;
        }
        .container-custom{
            margin-left: 50%;
        }
        .text-customs{
            color: #a748aa;
            margin-top: 10%;
        }
    </style>

    <title>JHFurniture View</title>
  </head>
  <body>
    <div class="container">
        <div class="d-flex justify-content-center text-custom">
        <h2>
           Furniture View
        </h2>
    </div>
    <?php if(session()->has('success')): ?>
    <div class="d-flex justify-content-center">
        <div class="alert alert-success alert-dismissible fade show col-5" role="alert">
                <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    </div>
    <?php endif; ?>

    <div class="d-flex justify-content-end">
        <div class="row">
            <div class="col">
            <form action="" method="GET">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Furniture's name" name="search">
                        <div class="input-group-append">
                          <button class="btn btn-custom" type="submit">Search</button>
                        </div>
                      </div>
                </form>
            </div>
        </div>
    </div>
    <?php if($furniture->isNotEmpty()): ?>
    <?php $__currentLoopData = $furniture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $furni): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="d-inline-flex p-2 mt-3">
        <div class="container-custom">
            <a href="details/<?php echo e($furni->id); ?>">
            <div class="card" style="width: 15rem; background-color:#a748aa">
                    <img src="<?php echo e($furni->image); ?>" class="card-img-top" alt="...">
                </a>
                <div class="card-body">
                    <div class="text-white text-center"> <?php echo e($furni->name); ?> </div>
                    <p class="card-text text-white text-center mt-2">Rp.<?php echo e(number_format($furni->price, 0, '.', '.')); ?></p>
                    <div class="d-flex justify-content-center">
                        <?php if(auth()->guard()->check()): ?>
                            <?php if( auth()->user()->role == 'Member'): ?>
                              <a href="<?php echo e(url('add')); ?>/<?php echo e($furni->id); ?>" class="btn btn-custom ">Add to Cart</a>
                            <?php endif; ?>
                        <?php else: ?>
                            <a href="/" class="btn btn-custom">Add to Cart</a>
                        <?php endif; ?>
                        <?php if(auth()->guard()->check()): ?>
                        <?php if(auth()->user()->role == 'Admin'): ?>
                        <div class="row text-center">
                            <div class="col-5"><a style="background-color: lime" class="btn text-white" href="<?php echo e(url('furniture/update')); ?>/<?php echo e($furni->id); ?>">Update</a></div>
                            <div class="col"></div>
                            <div class="col-5"><a style="background-color: red" class="btn text-white"  href="<?php echo e(url('furniture/delete')); ?>/<?php echo e($furni->id); ?>">Delete</a></div>
                        </div>
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    <div class="d-flex justify-content-center text-customs">
            <h2>
               No furniture found.
            </h2>
    </div>
    <?php endif; ?>

    <div class="d-flex justify-content-center mt-3">
        <?php echo e($furniture->links()); ?>

    </div>
    <br><br>
</div>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.container', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\JHFurniture\resources\views//view/index.blade.php ENDPATH**/ ?>