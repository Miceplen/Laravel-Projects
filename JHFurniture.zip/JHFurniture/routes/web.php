<?php

use App\Http\Controllers\CartController;
use App\Http\Controllers\FurnitureController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\TransactionController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*

|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', function () {
    return redirect('/login');
});


Route::get('/login', [LoginController::class, 'index'])->middleware('guest');
Route::post('/login', [LoginController::class, 'authenticate']);

Route::get('/register', [RegisterController::class, 'index'])->middleware('guest');
Route::post('/register', [RegisterController::class, 'store']);

Route::get('/home/index', [HomeController::class, 'index']);

Route::get('/profile/index', [ProfileController::class, 'index']);
Route::post('/logout', [ProfileController::class, 'logout']);

Route::get('/profile/update/{id}', [ProfileController::class, 'update']);
Route::post('/profile/update/', [ProfileController::class, 'updated']);

Route::get('/furniture/index', [FurnitureController::class, 'index']);
Route::get('/furniture/details/{id}', [FurnitureController::class, 'details']);

Route::get('/furniture/delete/{id}', [FurnitureController::class, 'delete']);
Route::get('/furniture/update/{id}', [FurnitureController::class, 'update']);
Route::post('/furniture/update/', [FurnitureController::class, 'updated']);

Route::get('furniture/add', [FurnitureController::class, 'add']);
Route::post('furniture/add', [FurnitureController::class, 'store']);


Route::get('/transaction/checkout', [CartController::class, 'order']);
Route::post('/transaction/checkout', [CartController::class, 'checkout']);

Route::get('/transaction/history', [CartController::class, 'history']);

Route::get('transaction/cart', [CartController::class, 'index']);
Route::get('add/{id}', [CartController::class, 'add']);
Route::get('/{id}/inc', [CartController::class, 'increment']);
Route::get('/{id}/dec', [CartController::class, 'decrement']);
