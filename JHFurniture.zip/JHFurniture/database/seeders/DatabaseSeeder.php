<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Facade;



class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();

        // $table->id()->autoIncrement();
        // $table->string('name');
        // $table->biginteger('price');
        // $table->string('color');
        // $table->binary('image');

        DB::table('furniture')->insert([
        [
            'id' => '1',
            'name' => 'Antilop',
            'price' => '200000',
            'color' => 'White',
            'image' => '/images/Antilop.jpg',
            'type' => 'Chair'

        ],
        [
            'id' => '2',
            'name' => 'Grimsbu',
            'price' => '1850000',
            'color' => 'White',
            'image' => "/images/Grimsbu.jpg",
            'type' => 'Bed'
        ],
        [
            'id' => '3',
            'name' => 'Hemlingby',
            'price' => '1850000',
            'color' => 'Black',
            'image' => '/images/Hemlingby.jpg',
            'type' => 'Sofa'
        ],
        [
            'id' => '4',
            'name' => 'Jessheim',
            'price' => '850000',
            'color' => 'Blue',
            'image' => '/images/Jessheim.jpg',
            'type' => 'Carpet'
        ],
        [
            'id' => '5',
            'name' => 'Knarrevik',
            'price' => '185000',
            'color' => 'Black',
            'image' => '/images/Knarrevik.jpg',
            'type' => 'Table'
        ],
        [
            'id' => '6',
            'name' => 'Lack',
            'price' => '145000',
            'color' => 'Black',
            'image' => '/images/Lack.jpg',
            'type' => 'Table'
        ],
        [
            'id' => '7',
            'name' => 'Mammut',
            'price' => '85000',
            'color' => 'White',
            'image' => '/images/Mammut.jpg',
            'type' => 'Chair'
        ],
        [
            'id' => '8',
            'name' => 'Melltorp',
            'price' => '225000',
            'color' => 'White',
            'image' => '/images/Melltorp.jpg',
            'type' => 'Table'
        ],
        [
            'id' => '9',
            'name' => 'Nesttun',
            'price' => '2150000',
            'color' => 'White',
            'image' => '/images/Nesttun.jpg',
            'type' => 'Bed'
        ],
        [
            'id' => '10',
            'name' => 'Theodores',
            'price' => '125000',
            'color' => 'White',
            'image' => '/images/Theodores.jpg',
            'type' => 'Chair'
        ],
        [
            'id' => '11',
            'name' => 'Vuku',
            'price' => '450000',
            'color' => 'White',
            'image' => '/images/Vuku.jpg',
            'type' => 'Wardrobe'
        ]

        ]);

    }
}
