<?php

namespace App\Http\Controllers;

use App\Models\Account;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class RegisterController extends Controller
{
    public function index(){
        return view('/register', [
            'title' => 'Register',
            'active' => 'register'
        ]);
    }

    public function store(Request $request){
        $data = $request->validate([
            'name' => 'required|alpha',
            'email' => 'required|email:dns|unique:account',
            'password' => 'required|min:5|max:20',
            'address' => 'required|min:5|max:95',
            'gender' => 'required|in:Male,Female',
        ]);

        $data['role'] = 'Member';

        $data['password'] = Hash::make($data['password']);

        Account::create($data);

    return redirect('/login')->with('success', 'Registration successful! Login Here.');
    }
}
