<?php

namespace App\Http\Controllers;

use App\Models\Furniture;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index(Request $request){

        $user = auth()->user();

        $request->session()->put('user', $user);

        $furniture = Furniture::all()->random(4);

        return view('/home/index', compact('furniture'));
    }

}
