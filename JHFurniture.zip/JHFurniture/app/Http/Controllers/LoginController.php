<?php

namespace App\Http\Controllers;

use App\Models\Account;
use CreateAccountTable;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Symfony\Component\Console\Input\Input;

class LoginController extends Controller
{
    public function index(){
        return view('/login', [
            'title' => 'Login',
            'active' => 'login'
        ]);
    }

    public function authenticate(Request $request){


        $credentials = $request->validate([
            'email' => 'required|email:dns',
            'password' => 'required|min:5|max:20'
        ]);

        $remember  = $request->has('remember') ? true:false;


        if (Auth::attempt($credentials, $remember)){

            $request->session()->regenerate();

            return redirect()->intended('home/index');
        }

        return back()->with('loginError', 'Invalid email or password, please try again.' );
    }


}
