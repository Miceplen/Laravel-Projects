<?php

namespace App\Http\Controllers;

use App\Models\Cart;
use App\Models\Furniture;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\URL;

class FurnitureController extends Controller
{
    public function index(Request $request){

        $search = $request->input('search');

        $furniture = Furniture::query()
            ->where('name', 'LIKE', "%{$search}%")
            ->paginate(4);

        return view('/furniture/index', compact('furniture'));
    }

    public function details($id){
        $data =  Furniture::find($id);
        return view('/furniture/details', ['furniture' => $data]);
    }

    public function update($id){
        $data =  Furniture::find($id);
        return view('/furniture/update', ['furniture' => $data]);
    }

    public function delete($id){
        $data = Furniture::find($id);
        $data->delete();

        return redirect('/home/index')->with('success_1', 'Successfully deleted a furniture.');
    }

    public function updated(Request $request){

        $data = $request->validate([
            'name' => 'required|alpha|max:15|unique:furniture',
            'price' => 'required|numeric',
            'type' => 'required',
            'color' => 'required',
            'image' => 'image|file'
        ]);


        $data = Furniture::find($request->id);

        if($request->file('image')){
            $data->image =  $request->file('image')->store('images');
        }

        $data->name = $request->name;
        $data->price = $request->price;
        $data->type = $request->type;
        $data->color = $request->color;
        $data->save();

        return redirect('/home/index')->with('success_1', 'Furniture has been successfully');
    }

    public function add(){

        return view('/furniture/add');
    }

    public function store(Request $request){
        $data = $request->validate([
            'name' => 'required|alpha|max:15|unique:furniture',
            'price' => 'required|numeric|min:5000|max:10000000',
            'type' => 'required',
            'color' => 'required',
            'image' => 'required|image|file'
        ]);

        $data['image'] =  $request->file('image')->store('images');

        Furniture::create($data);

    return redirect('/furniture/add')->with('success', 'Successfully added a furniture.');
    }


}
