<?php

namespace App\Http\Controllers;

use App\Models\Account;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class ProfileController extends Controller
{
    public function index(){
        return view('/profile/index');
    }

    public function logout(Request $request){
        Auth::logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect('/');
    }

    public function update($id){
        $data =  Account::find($id);
        return view('/profile/update', ['user' => $data]);
    }

    public function updated(Request $request){

        $data = $request->validate([
            'name' => 'required|alpha',
            'email' => 'required|email:dns',
            'password' => 'required|min:5|max:20',
            'address' => 'required|min:5|max:95'
        ]);


        $data = Account::find($request->id);

        $data->name = $request->name;
        $data->email = $request->email;
        $data->password = $request->password;
        $data->password = Hash::make($data->password);
        $data->address = $request->address;
        $data->save();

        return redirect('/profile/index')->with('success', 'Profile has been successfully updated.');
    }
}
