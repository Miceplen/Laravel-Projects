<?php

namespace App\Http\Controllers;

use App\Models\Account;
use App\Models\Furniture;
use App\Models\Transaction;
use Illuminate\Contracts\Session\Session;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\URL;
use Psy\Readline\Transient;

class CartController extends Controller
{

    public function index(){

        // dd(session('cart'));

        return view('transaction/cart');
    }

    public function add(Request $request, $id){

        if($request->session()->has('user')){

            $furniture = Furniture::find($id);

            $cart = session()->get('cart');

            $account_id = $request->session()->get('user')['id'];

            if(isset($cart[$id])){
                $cart[$id]['quantity'] += 1;
            }else{
                $cart[$id] = [
                    'id' => $id,
                    'account_id' => $account_id,
                    'name' => $furniture->name,
                    'price' => $furniture->price,
                    'image' => $furniture->image,
                    'quantity' => 1
                ];
            }

            session()->put('cart', $cart);

            return redirect(URL::previous())->with('success', 'An Item has successfully added into your cart.');

        }else{
            return redirect('/');
        }
    }

    public function increment($id){

        $cart = session()->get('cart');

        $cart[$id]['quantity'] += 1;

        session()->put('cart', $cart);

        return view('transaction/cart');
    }

    public function decrement($id){

        $cart = session()->get('cart');

        $cart[$id]['quantity'] -= 1;

        if($cart[$id]['quantity'] == 0){
            unset($cart[$id]);
        }

        session()->put('cart', $cart);

        return view('transaction/cart');
    }

    public function order(){
        return view('transaction/checkout');
    }

    public function checkout(Request $request){

        $carts = $request->session()->get('cart');

        foreach($carts as $cart){
            $transaction = new Transaction();
            $transaction->account_id = $cart['account_id'];
            $transaction->furniture_id = $cart['id'];
            $transaction->furniture_name = $cart['name'];
            $transaction->furniture_price = $cart['price'];
            $transaction->payment = $request->payment;
            $transaction->quantity = $cart['quantity'];
            $transaction->save();
        };
        $request->session()->forget('cart');

        return redirect('/home/index')->with('success_2', 'Your order has been successfully added.');
    }

    public function history(Request $request){
        $account_id = $request->session()->get('user', 'id');

        if( auth()->user()->role == 'Member' ){
           $orders =  DB::table('order')
                      ->where('account_id', $account_id->id)->get();
        }

        else if( auth()->user()->role == 'Admin' ){
            $orders =  DB::table('order')->get();
         }

        return view('/transaction/history', ['order' => $orders]);
    }
}
