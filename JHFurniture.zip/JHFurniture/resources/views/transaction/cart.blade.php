@extends('layouts.container')

@section('container')
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <style>
        .btn-custom{
            background-color: #a748aa;
            color: white;
        }
        .form-group{
            padding-top: 3%;
        }
        .container{
            width: 70%;
            margin-top: 5%;
        }
        .text-custom{
            color: #a748aa;
        }

    </style>

    <title>JHFurniture Cart</title>
  </head>
  <body>
    <div class="container">

        <div class="d-flex justify-content-center text-custom mb-3">
            <h2>
                Cart
            </h2>
        </div>

        <?php $total = 0 ?>
        <?php $totals = 0 ?>

    @if (session('cart'))
      @foreach (session('cart') as $items => $item)
        <?php $total += $item['price'] * $item['quantity'] ?>
        <div class="row">
            <div class="col"><img src="{{url('storage/'.$item['image'])}}" style="max-width: 100px;"></div>
            <div class="col fw-bold">{{$item['name']}}</div>
            <div class="col fw-bold">Rp.{{number_format($item['price'], 0, '.', '.')}}</div>
            <div class="col fw-bold">{{$item['quantity']}} item(s)</div>
            <div class="col fw-bold">Rp.{{number_format($total, 0, '.', '.')}}</div>
            <div class="col">
                <a href="{{url($item['id'])}}/inc" class="btn btn-custom col-3">+</a>
                <a href="{{url($item['id'])}}/dec" class="btn btn-custom col-3">-</a>
            </div>
          </div>
          <?php $totals+= $total ?>
      @endforeach
      <div class="d-flex mt-3">
      <div class="col fw-bold text-center">Total : Rp.{{number_format($totals, 0, '.', '.')}}</div>
      </div>
      <div class="d-flex justify-content-center mt-3">
          <a href="{{url('transaction/checkout')}}" class="btn btn-custom col-3">Proceed to Checkout</a>
      </div>
      @else
      <br><br>
      <div class="d-flex justify-content-center text-dark fw-bold">
        <h2>
            No Item has been added to cart.
        </h2>
    </div>



    @endif

    <br><br>

    </div>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>
@endsection
